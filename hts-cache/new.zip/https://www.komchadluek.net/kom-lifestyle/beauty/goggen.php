<html>
<head><title>410 Gone</title></head>
<body>
<center><h1>410 Gone</h1></center>
<hr><center>nginx/1.23.1</center>
</body>
</html>
